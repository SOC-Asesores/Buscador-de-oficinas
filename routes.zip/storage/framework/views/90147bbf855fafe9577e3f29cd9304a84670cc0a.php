<?php $__env->startSection('content'); ?>
	<div class="container px-4 mx-auto mt-10">
		<div class="flex px-4 mb-8 flex-wrap items-center">
            <figure class="md:w-1/3 w-1/2"><a href="https://socasesores.com/"><img src="https://socasesores.com/img/SOC1@300x.png" style="width: 200px;" alt=""></a></figure>
			<h4 class="md:w-1/3 w-1/2 md:text-xl text-lg text-primary text-center mb-3 font-bold">Ubica tu oficina</h4>

		</div>
		<div class="mb-8 w-full px-4">
			<form
				action="<?php echo e(URL::to('micrositios/search')); ?>"
				method="post"
				class="rounded md:px-9 px-4 py-9 bg-white-smoke shadow-sm">
				<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                <div class="md:flex items-center">
                    <div class="md:w-1/4 px-4 md:mb-0 mb-4">
        				<div class="relative bg-white text-black border border-grey-200 rounded">
        					<span class="absolute z-0 w-8 inset-y-0 flex items-center justify-center right-0 text-gray-400"><i class="fa fa-chevron-down" aria-hidden="true"></i></span>
        					<select name="state" class="relative z-10 bg-transparent appearance-none w-full h-10 pl-2 pr-8 text-gray-400 text-sm focus:outline-none">
        						<option class="bg-white text-black" selected hidden disabled>Estado</option>
        					<?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s => $state_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        						<option class="bg-white text-black" value="<?php echo e($s); ?>"><?php echo e($state_name); ?></option>
        					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        					</select>
        				</div>
                    </div>

                    <div class="md:w-1/4 px-4 md:mb-0 mb-4">
        				<div class="relative bg-white text-black border border-grey-200 rounded">
        					<span class="absolute z-0 w-8 inset-y-0 flex items-center justify-center right-0 text-gray-400"><i class="fa fa-chevron-down" aria-hidden="true"></i></span>
        					<select name="city" class="relative z-10 bg-transparent appearance-none w-full h-10 pl-2 pr-8 text-gray-400 text-sm focus:outline-none">
        						<option class="bg-white text-black" selected hidden disabled>Municipio</option>
        					</select>
        				</div>
                    </div>

                    <div class="md:w-1/4 px-4 md:mb-0 mb-4">
        				<div class="relative bg-white text-black border border-grey-200 rounded">
        					<span class="absolute z-0 w-8 inset-y-0 flex items-center justify-center right-0 text-gray-400"><i class="fa fa-chevron-down" aria-hidden="true"></i></span>
        					<select name="products" class="relative z-10 bg-transparent appearance-none w-full h-10 pl-2 pr-8 text-gray-400 text-sm focus:outline-none">
        						<option class="bg-white text-black" selected hidden disabled>Asesor&iacute;a</option>
        						<option class="bg-white text-black" value="Hipotecario">Hipotecario</option>
        						<option class="bg-white text-black" value="Empresarial">Empresarial</option>
        						<option class="bg-white text-black" value="Seguros">Seguros</option>
        						
        					</select>
        				</div>
                    </div>

                    <div class="md:w-1/4 px-4">
    				    <button type="submit" class="text-white bg-tertiary px-10 py-2 w-full rounded-md" >Buscar</button>
                    </div>
                </div>

			</form>
		</div>
		<div class="w-full px-4 md:block hidden">
			<div id="map" class="block w-full h-96 shadow-md"></div>
		</div>
	</div>
	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('scripts'); ?>
	<script
      src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(config('constants.google_maps_api_key')); ?>&callback=initMap&v=weekly"
      async
    ></script>
	<script type="text/javascript" src="<?php echo e(URL::asset('js/states.js?')); ?>"></script>
	<script type="text/javascript">
		let map;
        
        if($(window).width() >= 768){
            function initMap() {
    	    	var locations = <?php echo $locations; ?>;
    		  map = new google.maps.Map(document.getElementById("map"), {
    		    zoom: 5,
    		    center: new google.maps.LatLng(23.6260, -99.12766),
    		  });
    		  var infowindow = new google.maps.InfoWindow();
    
    		    var marker, i;
    		    
    		    for (i = 0; i < locations.length; i++) {  
    		      marker = new google.maps.Marker({
    		        position: new google.maps.LatLng(locations[i][1], locations[i][2]),
    		        icon: "<?php echo e(URL::asset('img')); ?>/"+locations[i][3],
    		        map: map
    		      });
    		      
    		      google.maps.event.addListener(marker, 'click', (function(marker, i) {
    		        return function() {
    		          infowindow.setContent(locations[i][0]);
    		          infowindow.open(map, marker);
    		        }
    		      })(marker, i));
    		    }
            }
        }
        
        
	</script>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp74\htdocs\buscador-soc\resources\views/offices.blade.php ENDPATH**/ ?>