<?php $__env->startSection('content'); ?>
	<section class="bg-white-smoke min-h-screen">
		<div class="py-10 bg-white">
            <div class="flex px-4 mb-8 flex-wrap items-center">
                <figure class="md:w-1/3 w-1/2"><a href="https://socasesores.com/"><img src="https://socasesores.com/img/SOC1@300x.png" style="width: 200px;" alt=""></a></figure>
                <h4 id="filtros_title" class="md:w-1/3 w-1/2 md:text-xl text-lg text-primary text-center mb-3 font-bold">Ubica tu oficina <span class="md:hidden">+</span></h4>

            </div>
			<div class="container px-4 mx-auto">
					<form
                        id="filtros"
						action="<?php echo e(URL::to('micrositios/search')); ?>"
						method="post"
						class="md:flex hidden items-center">
						<?php echo csrf_field(); ?>

						<div class="relative px-2 md:w-1/4">
							<div class="relative bg-white md:mb-0 mb-4 text-black border border-grey-200 rounded">
								<span class="absolute z-0 w-8 inset-y-0 flex items-center justify-center right-0 text-gray-400"><i class="fa fa-chevron-down" aria-hidden="true"></i></span>
								<select name="state" class="relative z-10 bg-transparent appearance-none w-full h-10 pl-2 pr-8 text-gray-400 text-sm focus:outline-none">
									<option class="bg-white text-black" <?php echo e(empty($state) ? 'selected' : ''); ?> hidden disabled>Estado</option>
								<?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s => $state_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

									<option class="bg-white text-black"  <?php echo e(!empty($state) && $state == $s ? 'selected' : ''); ?> value="<?php echo e($s); ?>"><?php echo e($state_name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								</select>
							</div>
						</div>
                        
						<div class="relative px-2 md:w-1/4">
							<div class="relative bg-white md:mb-0 mb-4 text-black border border-grey-200 rounded">
								<span class="absolute z-0 w-8 inset-y-0 flex items-center justify-center right-0 text-gray-400"><i class="fa fa-chevron-down" aria-hidden="true"></i></span>
								<select name="city" class="relative z-10 bg-transparent appearance-none w-full h-10 pl-2 pr-8 text-gray-400 text-sm focus:outline-none">
									<option class="bg-white text-black" <?php echo e(empty($municipio) ? 'selected' : ''); ?> hidden disabled>Municipio</option>
								</select>
							</div>
						</div>
						<div class="relative px-2 md:w-1/4">
							<div class="relative bg-white md:mb-0 mb-4 text-black border border-grey-200 rounded">
								<span class="absolute z-0 w-8 inset-y-0 flex items-center justify-center right-0 text-gray-400"><i class="fa fa-chevron-down" aria-hidden="true"></i></span>
								<select name="products" class="relative z-10 bg-transparent appearance-none w-full h-10 pl-2 pr-8 text-gray-400 text-sm focus:outline-none">
									<option class="bg-white text-black" <?php echo e(empty($products) ? 'selected' : ''); ?> hidden disabled>Asesor&iacute;a</option>
									<option class="bg-white text-black" <?php echo e(!empty($products) && $products == 'Hipotecario' ? 'selected' : ''); ?> value="Hipotecario">Hipotecario</option>
									<option class="bg-white text-black" <?php echo e(!empty($products) && $products == 'Empresarial' ? 'selected' : ''); ?> value="Empresarial">Empresarial</option>
									<option class="bg-white text-black" <?php echo e(!empty($products) && $products == 'Seguros' ? 'selected' : ''); ?> value="Seguros">Seguros</option>
									
								</select>
							</div>
						</div>
						<div class="relative px-2 md:w-1/4">
							<button type="submit" class="text-white bg-tertiary px-10 py-2 w-full rounded-md" >Buscar</button>
						</div>
					</form>
        		<div class="px-2 mt-6 text-sm" id="keywords">
        			<span class="inline-block">Filtros</span>
        			<div id="search_query" class="inline-block"></div>
        		
        		    <?php if(!empty($search)): ?>
            		<?php $__currentLoopData = $search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $query): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        			<div class="px-3 py-1 rounded relative inline-block text-white bg-secundary">
        				
        				<small class="relative z-10 value-item" data-name="<?php echo e($key); ?>"><?php echo e($query); ?></small>
        				<span class="click-item cursor-pointer ml-2 relative z-10"><i class="far fa-times-circle"></i></span>
        			</div>
        	        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        	        <?php endif; ?>
        	        
        		</div>
			</div>
		</div>
		<div data-count="<?php echo e(count($micrositios)); ?>" class="container py-6 md:px-8 px-4 grid lg:grid-cols-4 md:grid-cols-2 gap-8 gap-4 mx-auto mb-6">
		<?php if(!empty($micrositios)): ?>
		
			<?php $__currentLoopData = $micrositios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m => $micrositio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			<div data-i="<?php echo e($m); ?>" class="rounded-md <?php echo e(!empty($micrositio['certificacion']) && $micrositio['certificacion'] !== '0' ? 'border-2' : 'border'); ?> border-tertiary p-6 bg-white relative">
				<?php if(!empty($micrositio['certificacion']) && $micrositio['certificacion'] !== '0'): ?>
				<span class="absolute rounded-md inset-0 z-0 opacity-10 bg-tertiary"></span>
				<?php endif; ?>
				
				<div class="relative z-10">
                    <?php if(!empty($micrositio['certificacion']) && $micrositio['certificacion'] != '0'): ?>
                    <figure class="text-center mb-4">
                        <img src="<?php echo e(URL::asset('img/'.strtolower($micrositio['certificacion']).'.png')); ?>" alt="" class="h-4 w-auto max-w-full object-contain">
                    </figure>
                    <?php else: ?>
                    
                        
                    <?php endif; ?>  
					<figure class="md:w-auto w-4/5 flex mb-4">
						<img class="h-8 w-auto max-w-full object-contain mr-1 pl-1 border-l-px border-grey-200" src="<?php echo e(url('img/SOC1@300x.png')); ?>" alt="<?php echo e($micrositio['name']); ?>" />
						<span class="w-px bg-gray-300 block mx-1 flex-none"></span>
						<span class="<?php
							$l = strlen($micrositio['name']);
							if($l < 8){ echo 'text-2xl'; }
							elseif($l < 12){ echo 'text-xl'; }
							elseif($l < 18){ echo 'text-lg'; }
							elseif($l >= 18){ echo 'text-sm'; }
							?>
							self-center text-primary font-bold leading-none ml-1">
							<?php echo e($micrositio['name']); ?>

						</span>
					</figure>

					<?php if(!empty($micrositio['direccion'])): ?>
					<span class="flex items-start mb-4 text-sm">
						<img src="<?php echo e(URL::asset('img/location@2x.png')); ?>" class="w-4 flex-none mr-2"> <span><?php echo e($micrositio['direccion']); ?></span>
					</span>
					<?php endif; ?>
					<?php if(!empty($micrositio['telefono'])): ?>
					<a href="tel://<?php echo e($micrositio['telefono']); ?>" target="_blank" class="flex items-start mb-4 text-sm">
						<img src="<?php echo e(URL::asset('img/Grupo-25@2x.png')); ?>" class="w-4 flex-none mr-2"> <span><?php echo e($micrositio['telefono']); ?></span>
					</a>
					<?php endif; ?>
					<?php if(!empty($micrositio['email'])): ?>
					<a href="mailto:<?php echo e($micrositio['email']); ?>" target="_blank" class="flex items-start mb-4 text-sm">
						<img src="<?php echo e(URL::asset('img/vuesax-twotone-sms@2x.png')); ?>" class="w-4 flex-none mr-2"> <span><?php echo e(strlen($micrositio['email']) > 27 ? implode('@ ',explode('@',strtolower($micrositio['email']))) : strtolower($micrositio['email'])); ?></span>
					</a>
					<?php endif; ?>

					<div class="text-center">
					    <?php
    					    switch(@$micrositio['linea_de_negocio']){
    					        case 'seguros':
        					        $link = config('constants.base_link_seguros');
        					        break;
    					        case 'empresarial':
        					        $link = config('constants.base_link_empresarial');
        					        break;
    					        default:
    					            $link = config('constants.base_link_oficina');
    					        break;
					        }
					        $link = config('constants.nuevo_link_oficina');
					    ?>
					    
						
						<a href="<?php echo e($link.str_replace(' ','-',strtolower($micrositio['estado'])).'/'.str_replace(' ','-',strtolower($micrositio['ciudad'])).'/'.$micrositio['url']); ?>" class="font-bold underline text-tertiary">Ver m&aacute;s</a>
					</div>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
		<?php else: ?>
			<div class="container mx-auto">
				<h4 class="mb-4">No se encontró ningún resultado</h4>
			</div>
		<?php endif; ?>

		</div>
	</section>
	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('scripts'); ?>
	<script type="text/javascript" src="<?php echo e(URL::asset('js/states.js?')); ?>"></script>

	<script type="text/javascript">
    	$('body').on('click','.click-item',function(e) {
    		e.stopPropagation();
    		var name = $(this).prev().data('name');

			$('[name="'+ name +'"]').find("option:selected").prop("selected", false);
			$('[name="'+ name +'"]').find("option:first-child").prop("selected", true);
    
    		$(this).parent().remove();
    		$('form').submit();
    	});

        $('#filtros_title').click(function(e) {
            if($(window).width() < 768){
                var sign = $(this).find('span').html();
                if(sign == '+'){
                    sign = '-';
                } else{
                    sign = '+';
                }
                $(this).find('span').html(sign);
                $('#filtros').slideToggle();
            }
        })
    	
    	$(window).on('load',function(){
    	    var city_val = $('[data-name="city"]').html();
    	    if(city_val !== '' && city_val !== null){
    	        $('[name="city"]').val(city_val).change();
    	    }
    	});
	</script>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/socaseso/public_html/socasesores.com/buscador-soc/resources/views/offices_results.blade.php ENDPATH**/ ?>