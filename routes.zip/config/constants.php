<?php 

return [
	'base_link' => 'https://socasesores.com/micrositios-asesores/',
	'base_link_oficina' => 'https://socasesores.com/micrositios/',
	'base_link_seguros' => 'https://socasesores.com/micrositios-seguros/',
	'base_link_empresarial' => 'https://socasesores.com/micrositios-empresarial/',
	'nuevo_link_oficina' => 'https://socasesores.com/oficinas/',
	'google_maps_api_key' => 'AIzaSyDW9Bxi85KlmGQ6o_fk69a90rWr1E3NmDE',
];

 ?>